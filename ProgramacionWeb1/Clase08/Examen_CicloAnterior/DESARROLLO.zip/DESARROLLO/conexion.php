<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'practica';

    $conexion = mysqli_connect($servername, $username, $password, $dbname);

    if ($conexion == TRUE){
        echo 'Conectado correctamente<br><br>';
    }else{
        echo 'no se conecto';
    }
<?php

    include 'conexion.php';

    $usuario = $_POST['fusuario'];
    $password = $_POST['fpassword'];
    $mail = $_POST ['fmail'];

    $query = "INSERT INTO usuario (nombre_usuario, password, email) VALUE ('$usuario', '$password', '$mail')";

    $resultado = mysqli_query ($conexion, $query);

    if ($resultado == TRUE){ 
        ECHO 'Registrado correctamente';

    }else {
        ECHO 'No se pudo registrar';
    }

?>
<?php
    include 'conexion.php';

    listar($conexion);

    function listar($conexion){
    $query= "SELECT * FROM producto";

    $resultado = mysqli_query ($conexion, $query);

    if ($resultado -> num_rows>0){
      //poner bien los espacios  
        while ($fila  = mysqli_fetch_assoc($resultado)){
            echo "ID: ".$fila['ID_P'].'<BR>';
            echo "Nombre: ".$fila['nombre'].'<BR>';
            echo "Descripcion: ".$fila['descripcion'].'<BR>';
            echo "Precio: ".$fila['precio'].'<BR>';
            echo "Stock: ".$fila['stock'].'<BR>';
            echo "<hr>";
        }
    }else{
        echo 'DATOS NO ENCONTRADOS';
    }

    }
    
?>
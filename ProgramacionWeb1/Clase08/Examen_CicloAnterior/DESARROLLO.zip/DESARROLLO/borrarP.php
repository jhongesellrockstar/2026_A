<?php
    include 'conexion.php';

eliminar($conexion);

    function eliminar($conexion){

    $id = $_POST['fid'];
    

    $query = "DELETE FROM producto 
    
    WHERE 
    ID_P = '$id'";

    $resultado = mysqli_query ($conexion, $query);

    if ($resultado == TRUE){
        echo 'Se ha borrado correctamente';
    }else{
        echo 'No se borrado';
    }

    }
    
?>
<?php

    include 'conexion.php';

    crear($conexion);
    
    function crear($conexion){
        $id = $_POST ['fid'];
        $producto = $_POST ['fnombre'];
        $descripcion = $_POST ['fdescripcion'];
        $precio = $_POST ['fprecio'];
        $stock = $_POST ['fstock'];

        $query = "INSERT INTO producto (ID_P, nombre, descripcion, precio, stock) VALUE ('$id', '$producto', '$descripcion', '$precio', '$stock')";

        $resultado = mysqli_query($conexion, $query);

        if ($resultado == TRUE){
            echo 'Se ha agregado correctamente';
        }else {
            echo 'No se agrego el producto';
        }

    }
    
?>
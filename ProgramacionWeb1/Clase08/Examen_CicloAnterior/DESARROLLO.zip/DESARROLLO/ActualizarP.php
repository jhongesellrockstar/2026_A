<?php
    include 'conexion.php';

    actualizar($conexion);

    function actualizar($conexion){
        $id = $_POST['fid'];
        $nuev_nombre = $_POST['fnombre'];
        $nuev_descripcion = $_POST ['fdescripcion'];
        $nuev_precio = $_POST ['fprecio'];
        $nuev_stock = $_POST ['fstock'];

        $query = "UPDATE producto 
        SET nombre = '$nuev_nombre',
        descripcion = '$nuev_descripcion',
        precio = '$nuev_precio', 
        stock = '$nuev_stock'
        WHERE 
        ID_P = '$id'";

        $resultado = mysqli_query ($conexion, $query);

        if ($resultado == TRUE){
            echo 'Se ha actualizado correctamente';
        }else{
            echo 'No se actualizado';
        }

    }
    

?>
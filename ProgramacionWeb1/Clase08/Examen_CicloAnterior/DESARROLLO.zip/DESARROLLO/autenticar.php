<?php
    include 'conexion.php';

    $usuario = $_POST['fusuario'];
    $password = $_POST['fpassword'];

    $query = "SELECT * FROM usuario WHERE nombre_usuario = '$usuario' AND password = '$password'";

    $resultado = mysqli_query($conexion, $query);

    if ($resultado -> num_rows>0){
        echo 'BIENVENIDO';
        echo "<br><br> <a href='Producto.html'>PRODUCTOS</a>";
    }else{
        echo 'ERROR AL INGRESAR';
    }
?>
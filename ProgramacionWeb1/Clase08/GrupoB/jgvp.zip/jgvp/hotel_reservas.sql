-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-05-2026 a las 18:06:47
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hotel_reservas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `tipo_habitacion` varchar(20) NOT NULL,
  `precio_noche` decimal(10,2) NOT NULL,
  `noches` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `igv` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `cliente`, `tipo_habitacion`, `precio_noche`, `noches`, `subtotal`, `igv`, `total`, `fecha`, `hora`) VALUES
(1, 'jhon', 'Simple', 120.00, 2, 240.00, 43.20, 283.20, '2026-05-19', '10:29:41'),
(2, 'juan', 'Suite', 350.00, 1, 350.00, 63.00, 413.00, '2026-05-19', '11:03:21'),
(3, 'Raquel', 'Suite', 350.00, 3, 1050.00, 189.00, 1239.00, '2026-05-19', '11:03:37'),
(4, 'Juan Pérez', 'Suite', 350.00, 3, 1050.00, 189.00, 1239.00, '2026-05-19', '11:04:10'),
(5, 'Katherine', 'Simple', 120.00, 10, 1200.00, 216.00, 1416.00, '2026-05-19', '11:06:05'),
(6, 'Elizabeth', 'Simple', 120.00, 5, 600.00, 108.00, 708.00, '2026-05-19', '11:06:17');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

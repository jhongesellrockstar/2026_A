<?php
include("conexion.php");

$mensaje = "";

if ($_POST) {

    $cliente = trim($_POST['cliente']);
    $habitacion = $_POST['habitacion'];
    $noches = $_POST['noches'];

    // VALIDACIONES
    if ($cliente == "" || $habitacion == "" || $noches == "") {
        $mensaje = "Todos los campos son obligatorios";
    } elseif (!is_numeric($noches) || $noches <= 0) {
        $mensaje = "La cantidad de noches debe ser mayor a 0";
    } else {

        // TARIFAS
        switch ($habitacion) {
            case "Simple":
                $precio = 120;
                break;

            case "Doble":
                $precio = 200;
                break;

            case "Suite":
                $precio = 350;
                break;

            default:
                $precio = 0;
        }

        // CÁLCULOS
        $subtotal = $precio * $noches;
        $igv = $subtotal * 0.18;
        $total = $subtotal + $igv;

        // FECHA Y HORA
        date_default_timezone_set("America/Lima");

        $fecha = date("Y-m-d");
        $hora = date("H:i:s");

        // INSERTAR DATOS
        $sql = "INSERT INTO reservas
        (cliente, tipo_habitacion, precio_noche, noches, subtotal, igv, total, fecha, hora)
        VALUES
        ('$cliente', '$habitacion', '$precio', '$noches', '$subtotal', '$igv', '$total', '$fecha', '$hora')";

        if ($conn->query($sql) === TRUE) {

            $mensaje = "
            <h3>RESERVA REALIZADA</h3>

            Cliente: $cliente <br>
            Habitación: $habitacion <br>
            Precio por noche: S/ $precio <br>
            Noches: $noches <br>
            Subtotal: S/ $subtotal <br>
            IGV (18%): S/ $igv <br>
            Total a pagar: S/ $total <br>
            Fecha: $fecha <br>
            Hora: $hora
            ";
        } else {
            $mensaje = "Error al guardar";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sistema de Reserva de Hotel</title>

    <style>

        body{
            font-family: Arial;
            background:#f4f4f4;
        }

        .contenedor{
            width:500px;
            margin:auto;
            background:white;
            padding:20px;
            border-radius:10px;
        }

        input, select{
            width:100%;
            padding:10px;
            margin-bottom:10px;
        }

        button{
            background:blue;
            color:white;
            padding:10px;
            border:none;
            width:100%;
        }

        table{
            width:100%;
            border-collapse:collapse;
            margin-top:20px;
        }

        table, th, td{
            border:1px solid black;
        }

        th, td{
            padding:10px;
            text-align:center;
        }

    </style>

</head>
<body>

<div class="contenedor">

    <h2>Reserva de Hotel</h2>

    <form method="POST">

        <label>Nombre del Cliente</label>
        <input type="text" name="cliente">

        <label>Tipo de Habitación</label>
        <select name="habitacion">
            <option value="">Seleccione</option>
            <option value="Simple">Simple</option>
            <option value="Doble">Doble</option>
            <option value="Suite">Suite</option>
        </select>

        <label>Cantidad de Noches</label>
        <input type="number" name="noches">

        <button type="submit">Registrar Reserva</button>

    </form>

    <br>

    <?php echo $mensaje; ?>

    <hr>

    <h2>Reservas Realizadas</h2>

    <table>

        <tr>
            <th>Cliente</th>
            <th>Habitación</th>
            <th>Precio</th>
            <th>Noches</th>
            <th>Subtotal</th>
            <th>IGV</th>
            <th>Total</th>
            <th>Fecha</th>
            <th>Hora</th>
        </tr>

        <?php

        $sql = "SELECT * FROM reservas ORDER BY id DESC";
        $resultado = $conn->query($sql);

        while($fila = $resultado->fetch_assoc()){

        ?>

        <tr>
            <td><?php echo $fila['cliente']; ?></td>
            <td><?php echo $fila['tipo_habitacion']; ?></td>
            <td>S/ <?php echo $fila['precio_noche']; ?></td>
            <td><?php echo $fila['noches']; ?></td>
            <td>S/ <?php echo $fila['subtotal']; ?></td>
            <td>S/ <?php echo $fila['igv']; ?></td>
            <td>S/ <?php echo $fila['total']; ?></td>
            <td><?php echo $fila['fecha']; ?></td>
            <td><?php echo $fila['hora']; ?></td>
        </tr>

        <?php } ?>

    </table>

</div>

</body>
</html>
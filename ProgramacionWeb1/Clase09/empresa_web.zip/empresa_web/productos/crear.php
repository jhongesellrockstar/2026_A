<?php
$titulo_pagina = "Nuevo producto";
include "../conexion.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_producto = trim($_POST["nombre_producto"]);
    $id_categoria = intval($_POST["id_categoria"]);
    $descripcion = trim($_POST["descripcion"]);
    $precio = trim($_POST["precio"]);
    $stock = trim($_POST["stock"]);

    if (empty($nombre_producto) || $id_categoria <= 0) {
        $mensaje = "El nombre y la categoria son obligatorios.";
    } elseif (!is_numeric($precio) || $precio <= 0) {
        $mensaje = "El precio debe ser mayor que cero.";
    } elseif (!is_numeric($stock) || $stock < 0) {
        $mensaje = "El stock no puede ser negativo.";
    } else {
        // mysqli_real_escape_string ayuda a evitar problemas con comillas en los textos.
        $nombre_producto = mysqli_real_escape_string($conexion, $nombre_producto);
        $descripcion = mysqli_real_escape_string($conexion, $descripcion);
        $precio = floatval($precio);
        $stock = intval($stock);

        $sql = "INSERT INTO productos (id_categoria, nombre_producto, descripcion, precio, stock)
                VALUES ($id_categoria, '$nombre_producto', '$descripcion', $precio, $stock)";

        if (mysqli_query($conexion, $sql)) {
            header("Location: listar.php?mensaje=Producto registrado correctamente");
            exit;
        } else {
            $mensaje = "No se pudo registrar el producto.";
        }
    }
}

$categorias = mysqli_query($conexion, "SELECT * FROM categorias ORDER BY nombre_categoria");

include "../includes/header.php";
include "../includes/menu.php";
?>

<main class="contenedor">
    <h1>Nuevo producto</h1>
    <?php if ($mensaje != "") { ?><div class="mensaje error"><?php echo $mensaje; ?></div><?php } ?>

    <form class="formulario" id="formProducto" method="POST" onsubmit="return validarFormularioProductos()">
        <div class="campo">
            <label for="nombre_producto">Nombre</label>
            <input type="text" id="nombre_producto" name="nombre_producto" placeholder="Ejemplo: Mouse Logitech USB" required>
        </div>
        <div class="campo">
            <label for="id_categoria">Categoria</label>
            <select id="id_categoria" name="id_categoria" required>
                <option value="">Seleccione</option>
                <?php while ($fila = mysqli_fetch_assoc($categorias)) { ?>
                    <option value="<?php echo $fila["id_categoria"]; ?>"><?php echo $fila["nombre_categoria"]; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="campo">
            <label for="descripcion">Descripcion</label>
            <input type="text" id="descripcion" name="descripcion" maxlength="150" placeholder="Descripcion corta del producto">
        </div>
        <div class="campo">
            <label for="precio">Precio</label>
            <input type="number" id="precio" step="0.01" min="0.01" name="precio" placeholder="Ejemplo: 45.00" required>
        </div>
        <div class="campo">
            <label for="stock">Stock</label>
            <input type="number" id="stock" min="0" name="stock" placeholder="Ejemplo: 20" required>
        </div>
        <button class="boton-secundario" type="submit">Guardar</button>
        <a class="boton-editar" href="listar.php">Cancelar</a>
        <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
    </form>
</main>

<?php include "../includes/footer.php"; ?>

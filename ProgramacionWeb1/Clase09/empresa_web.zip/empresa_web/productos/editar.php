<?php
$titulo_pagina = "Editar producto";
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_producto = trim($_POST["nombre_producto"]);
    $id_categoria = intval($_POST["id_categoria"]);
    $descripcion = trim($_POST["descripcion"]);
    $precio = trim($_POST["precio"]);
    $stock = trim($_POST["stock"]);

    if ($id <= 0 || empty($nombre_producto) || $id_categoria <= 0) {
        $mensaje = "El nombre y la categoria son obligatorios.";
    } elseif (!is_numeric($precio) || $precio <= 0) {
        $mensaje = "El precio debe ser mayor que cero.";
    } elseif (!is_numeric($stock) || $stock < 0) {
        $mensaje = "El stock no puede ser negativo.";
    } else {
        // mysqli_real_escape_string ayuda a evitar problemas con comillas en los textos.
        $nombre_producto = mysqli_real_escape_string($conexion, $nombre_producto);
        $descripcion = mysqli_real_escape_string($conexion, $descripcion);
        $precio = floatval($precio);
        $stock = intval($stock);

        $sql = "UPDATE productos SET nombre_producto='$nombre_producto', id_categoria=$id_categoria,
                descripcion='$descripcion', precio=$precio, stock=$stock
                WHERE id_producto=$id";

        if (mysqli_query($conexion, $sql)) {
            header("Location: listar.php?mensaje=Producto actualizado correctamente");
            exit;
        } else {
            $mensaje = "No se pudo actualizar el producto.";
        }
    }
}

$resultado = mysqli_query($conexion, "SELECT * FROM productos WHERE id_producto = $id");
$producto = mysqli_fetch_assoc($resultado);
$categorias = mysqli_query($conexion, "SELECT * FROM categorias ORDER BY nombre_categoria");

include "../includes/header.php";
include "../includes/menu.php";
?>

<main class="contenedor">
    <h1>Editar producto</h1>
    <?php if ($mensaje != "") { ?><div class="mensaje error"><?php echo $mensaje; ?></div><?php } ?>

    <?php if (!$producto) { ?>
        <div class="mensaje error">No se encontro el producto solicitado.</div>
        <a class="boton-editar" href="listar.php">Volver</a>
    <?php } else { ?>
        <form class="formulario" id="formProducto" method="POST" onsubmit="return validarFormularioProductos()">
            <div class="campo">
                <label for="nombre_producto">Nombre</label>
                <input type="text" id="nombre_producto" name="nombre_producto" value="<?php echo $producto["nombre_producto"]; ?>" placeholder="Ejemplo: Mouse Logitech USB" required>
            </div>
            <div class="campo">
                <label for="id_categoria">Categoria</label>
                <select id="id_categoria" name="id_categoria" required>
                    <?php while ($fila = mysqli_fetch_assoc($categorias)) { ?>
                        <option value="<?php echo $fila["id_categoria"]; ?>" <?php if ($fila["id_categoria"] == $producto["id_categoria"]) { echo "selected"; } ?>>
                            <?php echo $fila["nombre_categoria"]; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="campo">
                <label for="descripcion">Descripcion</label>
                <input type="text" id="descripcion" name="descripcion" value="<?php echo $producto["descripcion"]; ?>" maxlength="150" placeholder="Descripcion corta del producto">
            </div>
            <div class="campo">
                <label for="precio">Precio</label>
                <input type="number" id="precio" step="0.01" min="0.01" name="precio" value="<?php echo $producto["precio"]; ?>" placeholder="Ejemplo: 45.00" required>
            </div>
            <div class="campo">
                <label for="stock">Stock</label>
                <input type="number" id="stock" min="0" name="stock" value="<?php echo $producto["stock"]; ?>" placeholder="Ejemplo: 20" required>
            </div>
            <button class="boton-secundario" type="submit">Actualizar</button>
            <a class="boton-editar" href="listar.php">Cancelar</a>
            <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
        </form>
    <?php } ?>
</main>

<?php include "../includes/footer.php"; ?>

<?php
$titulo_pagina = "Productos";
include "../includes/header.php";
include "../includes/menu.php";
include "../conexion.php";

// JOIN para mostrar el nombre de la categoria relacionada con cada producto.
$consulta = "SELECT productos.id_producto, productos.nombre_producto, productos.descripcion,
            productos.precio, productos.stock, categorias.nombre_categoria
            FROM productos
            INNER JOIN categorias ON productos.id_categoria = categorias.id_categoria
            ORDER BY productos.id_producto DESC";
$resultado = mysqli_query($conexion, $consulta);
?>

<main class="contenedor">
    <section class="encabezado-pagina acciones">
        <div>
            <h1>Productos</h1>
            <p>Listado de productos disponibles para la venta.</p>
        </div>
        <div>
            <a class="boton-secundario" href="crear.php">Nuevo producto</a>
            <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
        </div>
    </section>

    <?php if (isset($_GET["mensaje"])) { ?><div class="mensaje ok"><?php echo $_GET["mensaje"]; ?></div><?php } ?>
    <?php if (isset($_GET["error"])) { ?><div class="mensaje error"><?php echo $_GET["error"]; ?></div><?php } ?>

    <div class="tabla-contenedor">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Categoria</th>
                    <th>Descripcion</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                    <tr class="<?php if ($fila["stock"] <= 5) { echo "stock-bajo"; } ?>">
                        <td><?php echo $fila["id_producto"]; ?></td>
                        <td><?php echo $fila["nombre_producto"]; ?></td>
                        <td><?php echo $fila["nombre_categoria"]; ?></td>
                        <td><?php echo $fila["descripcion"]; ?></td>
                        <td>S/ <?php echo $fila["precio"]; ?></td>
                        <td>
                            <?php echo $fila["stock"]; ?>
                            <?php if ($fila["stock"] <= 5) { ?><span class="etiqueta-stock">Stock bajo</span><?php } ?>
                        </td>
                        <td>
                            <a class="boton-editar" href="editar.php?id=<?php echo $fila["id_producto"]; ?>">Editar</a>
                            <a class="boton-eliminar" href="eliminar.php?id=<?php echo $fila["id_producto"]; ?>" onclick="return confirmarEliminacion('este producto')">Eliminar</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</main>

<?php include "../includes/footer.php"; ?>

<?php
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

if ($id > 0) {
    $sql = "DELETE FROM productos WHERE id_producto = $id";

    if (mysqli_query($conexion, $sql)) {
        header("Location: listar.php?mensaje=Producto eliminado correctamente");
        exit;
    }
}

header("Location: listar.php?error=No se pudo eliminar el producto. Puede tener ventas registradas.");
exit;
?>

USE bd_empresa_web;

-- 1. Mostrar todos los clientes.
SELECT * FROM clientes;

-- 2. Mostrar productos con su categoria.
SELECT productos.id_producto,
       productos.nombre_producto,
       categorias.nombre_categoria,
       productos.precio,
       productos.stock
FROM productos
INNER JOIN categorias ON productos.id_categoria = categorias.id_categoria;

-- 3. Mostrar ventas con cliente y empleado.
SELECT ventas.id_venta,
       ventas.fecha_venta,
       clientes.nombres AS cliente,
       empleados.nombres AS empleado,
       ventas.total
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado;

-- 4. Mostrar detalle de ventas con productos.
SELECT detalle_ventas.id_detalle,
       ventas.id_venta,
       productos.nombre_producto,
       detalle_ventas.cantidad,
       detalle_ventas.precio_unitario,
       detalle_ventas.subtotal
FROM detalle_ventas
INNER JOIN ventas ON detalle_ventas.id_venta = ventas.id_venta
INNER JOIN productos ON detalle_ventas.id_producto = productos.id_producto;

-- 5. Calcular total vendido por venta usando el detalle.
SELECT ventas.id_venta,
       clientes.nombres AS cliente,
       SUM(detalle_ventas.subtotal) AS total_calculado
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
INNER JOIN detalle_ventas ON ventas.id_venta = detalle_ventas.id_venta
GROUP BY ventas.id_venta, clientes.nombres;

-- 6. Mostrar productos con bajo stock.
SELECT nombre_producto, stock
FROM productos
WHERE stock <= 10
ORDER BY stock ASC;

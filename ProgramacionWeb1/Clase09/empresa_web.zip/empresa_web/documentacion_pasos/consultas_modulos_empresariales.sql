USE bd_empresa_web;

-- Listar clientes.
SELECT id_cliente, nombres, dni, telefono, correo, direccion, fecha_registro
FROM clientes;

-- Listar empleados.
SELECT id_empleado, nombres, cargo, telefono, correo, fecha_contratacion
FROM empleados;

-- Listar productos con categoria.
SELECT productos.id_producto,
       productos.nombre_producto,
       categorias.nombre_categoria,
       productos.descripcion,
       productos.precio,
       productos.stock
FROM productos
INNER JOIN categorias ON productos.id_categoria = categorias.id_categoria;

-- Listar ventas con cliente y empleado.
SELECT ventas.id_venta,
       clientes.nombres AS cliente,
       empleados.nombres AS empleado,
       ventas.fecha_venta,
       ventas.total
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado;

-- Listar detalle de una venta con productos.
SELECT detalle_ventas.id_venta,
       productos.nombre_producto,
       detalle_ventas.cantidad,
       detalle_ventas.precio_unitario,
       detalle_ventas.subtotal
FROM detalle_ventas
INNER JOIN productos ON detalle_ventas.id_producto = productos.id_producto
WHERE detalle_ventas.id_venta = 1;

-- Consultar stock actual de productos.
SELECT id_producto, nombre_producto, stock
FROM productos
ORDER BY stock ASC;

-- Consultar ventas por cliente.
SELECT clientes.nombres AS cliente,
       ventas.id_venta,
       ventas.fecha_venta,
       ventas.total
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
ORDER BY clientes.nombres, ventas.fecha_venta;

-- Consultar ventas por empleado.
SELECT empleados.nombres AS empleado,
       ventas.id_venta,
       ventas.fecha_venta,
       ventas.total
FROM ventas
INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado
ORDER BY empleados.nombres, ventas.fecha_venta;

-- Consultar total vendido por producto.
SELECT productos.nombre_producto,
       SUM(detalle_ventas.cantidad) AS unidades_vendidas,
       SUM(detalle_ventas.subtotal) AS total_vendido
FROM detalle_ventas
INNER JOIN productos ON detalle_ventas.id_producto = productos.id_producto
GROUP BY productos.nombre_producto
ORDER BY total_vendido DESC;

-- Consultar productos con stock bajo.
SELECT id_producto, nombre_producto, stock
FROM productos
WHERE stock <= 5
ORDER BY stock ASC;

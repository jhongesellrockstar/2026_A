USE bd_empresa_web;

-- Insertar un cliente.
INSERT INTO clientes (nombres, dni, telefono, correo, direccion)
VALUES ('Cliente de Prueba', '45678912', '900111222', 'cliente.prueba@email.com', 'Av. Prueba 123 - Callao');

-- Listar clientes.
SELECT id_cliente, nombres, dni, telefono, correo, direccion, fecha_registro
FROM clientes;

-- Actualizar un cliente.
UPDATE clientes
SET telefono = '999888777', direccion = 'Nueva direccion 456'
WHERE id_cliente = 1;

-- Eliminar un cliente.
DELETE FROM clientes
WHERE id_cliente = 5;

-- Insertar un producto.
INSERT INTO productos (id_categoria, nombre_producto, descripcion, precio, stock)
VALUES (2, 'Cable HDMI 2 metros', 'Cable para video y audio digital', 35.00, 20);

-- Listar productos con categoria mediante JOIN.
SELECT productos.id_producto,
       productos.nombre_producto,
       categorias.nombre_categoria,
       productos.precio,
       productos.stock
FROM productos
INNER JOIN categorias ON productos.id_categoria = categorias.id_categoria;

-- Actualizar stock de producto.
UPDATE productos
SET stock = stock - 1
WHERE id_producto = 1;

-- Eliminar un producto.
DELETE FROM productos
WHERE nombre_producto = 'Cable HDMI 2 metros';

-- Listar ventas con cliente y empleado usando JOIN.
SELECT ventas.id_venta,
       ventas.fecha_venta,
       clientes.nombres AS cliente,
       empleados.nombres AS empleado,
       ventas.total
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado;

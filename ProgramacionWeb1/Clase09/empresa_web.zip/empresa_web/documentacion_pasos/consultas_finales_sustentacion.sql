USE bd_empresa_web;

-- Ver todas las tablas de la base de datos.
SHOW TABLES;

-- Listar clientes.
SELECT id_cliente, nombres, dni, telefono, correo, direccion, fecha_registro
FROM clientes;

-- Listar empleados.
SELECT id_empleado, nombres, cargo, telefono, correo, fecha_contratacion
FROM empleados;

-- Listar productos con categoria.
SELECT productos.id_producto,
       productos.nombre_producto,
       categorias.nombre_categoria,
       productos.descripcion,
       productos.precio,
       productos.stock
FROM productos
INNER JOIN categorias ON productos.id_categoria = categorias.id_categoria;

-- Listar ventas con cliente y empleado.
SELECT ventas.id_venta,
       clientes.nombres AS cliente,
       empleados.nombres AS empleado,
       ventas.fecha_venta,
       ventas.total
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado;

-- Ver detalle de una venta.
SELECT ventas.id_venta,
       productos.nombre_producto,
       detalle_ventas.cantidad,
       detalle_ventas.precio_unitario,
       detalle_ventas.subtotal
FROM detalle_ventas
INNER JOIN ventas ON detalle_ventas.id_venta = ventas.id_venta
INNER JOIN productos ON detalle_ventas.id_producto = productos.id_producto
WHERE ventas.id_venta = 1;

-- Ver productos con bajo stock.
SELECT id_producto, nombre_producto, stock
FROM productos
WHERE stock <= 5
ORDER BY stock ASC;

-- Calcular total general de ventas.
SELECT SUM(total) AS total_general_vendido
FROM ventas;

-- Contar registros por tabla.
SELECT 'clientes' AS tabla, COUNT(*) AS total FROM clientes
UNION ALL
SELECT 'empleados', COUNT(*) FROM empleados
UNION ALL
SELECT 'categorias', COUNT(*) FROM categorias
UNION ALL
SELECT 'productos', COUNT(*) FROM productos
UNION ALL
SELECT 'ventas', COUNT(*) FROM ventas
UNION ALL
SELECT 'detalle_ventas', COUNT(*) FROM detalle_ventas;

-- Mostrar relaciones principales con JOIN.
SELECT ventas.id_venta,
       clientes.nombres AS cliente,
       empleados.nombres AS empleado,
       productos.nombre_producto,
       categorias.nombre_categoria,
       detalle_ventas.cantidad,
       detalle_ventas.subtotal
FROM ventas
INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado
INNER JOIN detalle_ventas ON ventas.id_venta = detalle_ventas.id_venta
INNER JOIN productos ON detalle_ventas.id_producto = productos.id_producto
INNER JOIN categorias ON productos.id_categoria = categorias.id_categoria;

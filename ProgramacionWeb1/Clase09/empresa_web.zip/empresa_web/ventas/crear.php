<?php
$titulo_pagina = "Nueva venta";
include "../conexion.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_cliente = intval($_POST["id_cliente"]);
    $id_empleado = intval($_POST["id_empleado"]);
    $id_producto = intval($_POST["id_producto"]);
    $cantidad = trim($_POST["cantidad"]);

    // Validaciones basicas antes de registrar la venta.
    if ($id_cliente <= 0 || $id_empleado <= 0 || $id_producto <= 0) {
        $mensaje = "Debes seleccionar cliente, empleado y producto.";
    } elseif (!is_numeric($cantidad) || $cantidad <= 0) {
        $mensaje = "La cantidad debe ser mayor que cero.";
    } else {
        $cantidad = intval($cantidad);
        $existe_cliente = mysqli_query($conexion, "SELECT id_cliente FROM clientes WHERE id_cliente = $id_cliente");
        $existe_empleado = mysqli_query($conexion, "SELECT id_empleado FROM empleados WHERE id_empleado = $id_empleado");
        $consulta_producto = mysqli_query($conexion, "SELECT precio, stock FROM productos WHERE id_producto = $id_producto");
        $producto = mysqli_fetch_assoc($consulta_producto);

        if (mysqli_num_rows($existe_cliente) == 0) {
            $mensaje = "El cliente seleccionado no existe.";
        } elseif (mysqli_num_rows($existe_empleado) == 0) {
            $mensaje = "El empleado seleccionado no existe.";
        } elseif (!$producto) {
            $mensaje = "El producto seleccionado no existe.";
        } elseif ($producto["stock"] < $cantidad) {
            $mensaje = "No hay stock suficiente. Stock actual: " . $producto["stock"];
        } else {
            $precio = $producto["precio"];
            $subtotal = $precio * $cantidad;

            $sql_venta = "INSERT INTO ventas (id_cliente, id_empleado, total)
                          VALUES ($id_cliente, $id_empleado, $subtotal)";

            if (mysqli_query($conexion, $sql_venta)) {
                $id_venta = mysqli_insert_id($conexion);

                $sql_detalle = "INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, precio_unitario, subtotal)
                                VALUES ($id_venta, $id_producto, $cantidad, $precio, $subtotal)";
                $detalle_guardado = mysqli_query($conexion, $sql_detalle);

                if ($detalle_guardado) {
                    // Se descuenta del stock la cantidad vendida.
                    $nuevo_stock = $producto["stock"] - $cantidad;
                    mysqli_query($conexion, "UPDATE productos SET stock = $nuevo_stock WHERE id_producto = $id_producto");

                    header("Location: detalle.php?id=$id_venta&mensaje=Venta registrada correctamente");
                    exit;
                } else {
                    $mensaje = "La venta se creo, pero no se pudo registrar el detalle.";
                }
            } else {
                $mensaje = "No se pudo registrar la venta.";
            }
        }
    }
}

$clientes = mysqli_query($conexion, "SELECT * FROM clientes ORDER BY nombres");
$empleados = mysqli_query($conexion, "SELECT * FROM empleados ORDER BY nombres");
$productos = mysqli_query($conexion, "SELECT * FROM productos WHERE stock > 0 ORDER BY nombre_producto");

include "../includes/header.php";
include "../includes/menu.php";
?>

<main class="contenedor">
    <h1>Nueva venta</h1>
    <p>Formulario inicial: registra una venta con un producto y actualiza el stock.</p>

    <?php if ($mensaje != "") { ?><div class="mensaje error"><?php echo $mensaje; ?></div><?php } ?>

    <form class="formulario" id="formVenta" method="POST" onsubmit="return validarFormularioVentas()">
        <div class="campo">
            <label for="id_cliente">Cliente</label>
            <select id="id_cliente" name="id_cliente" required>
                <option value="">Seleccione</option>
                <?php while ($fila = mysqli_fetch_assoc($clientes)) { ?>
                    <option value="<?php echo $fila["id_cliente"]; ?>"><?php echo $fila["nombres"]; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="campo">
            <label for="id_empleado">Empleado</label>
            <select id="id_empleado" name="id_empleado" required>
                <option value="">Seleccione</option>
                <?php while ($fila = mysqli_fetch_assoc($empleados)) { ?>
                    <option value="<?php echo $fila["id_empleado"]; ?>"><?php echo $fila["nombres"]; ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="campo">
            <label for="id_producto">Producto</label>
            <select id="id_producto" name="id_producto" required>
                <option value="">Seleccione</option>
                <?php while ($fila = mysqli_fetch_assoc($productos)) { ?>
                    <option value="<?php echo $fila["id_producto"]; ?>">
                        <?php echo $fila["nombre_producto"]; ?> - S/ <?php echo $fila["precio"]; ?> - Stock: <?php echo $fila["stock"]; ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="campo">
            <label for="cantidad">Cantidad</label>
            <input type="number" id="cantidad" name="cantidad" min="1" placeholder="Ejemplo: 1" required>
        </div>

        <button class="boton-secundario" type="submit">Registrar venta</button>
        <a class="boton-editar" href="listar.php">Cancelar</a>
        <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
    </form>
</main>

<?php include "../includes/footer.php"; ?>

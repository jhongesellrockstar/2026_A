<?php
$titulo_pagina = "Ventas";
include "../includes/header.php";
include "../includes/menu.php";
include "../conexion.php";

// JOIN permite mostrar datos relacionados de clientes y empleados.
$consulta = "SELECT ventas.id_venta, ventas.fecha_venta, ventas.total,
            clientes.nombres AS cliente,
            empleados.nombres AS empleado
            FROM ventas
            INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
            INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado
            ORDER BY ventas.id_venta DESC";
$resultado = mysqli_query($conexion, $consulta);
?>

<main class="contenedor">
    <section class="encabezado-pagina acciones">
        <div>
            <h1>Ventas</h1>
            <p>Registro de ventas realizadas por la empresa.</p>
        </div>
        <div>
            <a class="boton-secundario" href="crear.php">Nueva venta</a>
            <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
        </div>
    </section>

    <?php if (isset($_GET["mensaje"])) { ?><div class="mensaje ok"><?php echo $_GET["mensaje"]; ?></div><?php } ?>
    <?php if (isset($_GET["error"])) { ?><div class="mensaje error"><?php echo $_GET["error"]; ?></div><?php } ?>

    <div class="tabla-contenedor">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th>Empleado</th>
                    <th>Total</th>
                    <th>Detalle</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                    <tr>
                        <td><?php echo $fila["id_venta"]; ?></td>
                        <td><?php echo $fila["fecha_venta"]; ?></td>
                        <td><?php echo $fila["cliente"]; ?></td>
                        <td><?php echo $fila["empleado"]; ?></td>
                        <td>S/ <?php echo $fila["total"]; ?></td>
                        <td><a class="boton-editar" href="detalle.php?id=<?php echo $fila["id_venta"]; ?>">Ver detalle</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</main>

<?php include "../includes/footer.php"; ?>

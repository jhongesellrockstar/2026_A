<?php
$titulo_pagina = "Detalle de venta";
include "../includes/header.php";
include "../includes/menu.php";
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

$consulta_venta = "SELECT ventas.id_venta, ventas.fecha_venta, ventas.total,
                  clientes.nombres AS cliente,
                  empleados.nombres AS empleado
                  FROM ventas
                  INNER JOIN clientes ON ventas.id_cliente = clientes.id_cliente
                  INNER JOIN empleados ON ventas.id_empleado = empleados.id_empleado
                  WHERE ventas.id_venta = $id";
$resultado_venta = mysqli_query($conexion, $consulta_venta);
$venta = mysqli_fetch_assoc($resultado_venta);

$consulta_detalle = "SELECT detalle_ventas.cantidad, detalle_ventas.precio_unitario,
                    detalle_ventas.subtotal, productos.nombre_producto AS producto
                    FROM detalle_ventas
                    INNER JOIN productos ON detalle_ventas.id_producto = productos.id_producto
                    WHERE detalle_ventas.id_venta = $id";
$resultado_detalle = mysqli_query($conexion, $consulta_detalle);
?>

<main class="contenedor">
    <?php if (!$venta) { ?>
        <div class="mensaje error">No se encontro la venta solicitada.</div>
        <a class="boton-editar" href="listar.php">Volver</a>
    <?php } else { ?>
    <?php if (isset($_GET["mensaje"])) { ?><div class="mensaje ok"><?php echo $_GET["mensaje"]; ?></div><?php } ?>
    <section class="encabezado-pagina">
        <h1>Detalle de venta Nro. <?php echo $venta["id_venta"]; ?></h1>
        <p>Cliente: <?php echo $venta["cliente"]; ?> | Empleado: <?php echo $venta["empleado"]; ?> | Fecha: <?php echo $venta["fecha_venta"]; ?></p>
    </section>

    <div class="detalle-resumen">
        <p><strong>Numero de venta:</strong> <?php echo $venta["id_venta"]; ?></p>
        <p><strong>Cliente:</strong> <?php echo $venta["cliente"]; ?></p>
        <p><strong>Empleado:</strong> <?php echo $venta["empleado"]; ?></p>
        <p><strong>Fecha:</strong> <?php echo $venta["fecha_venta"]; ?></p>
        <p><strong>Total:</strong> S/ <?php echo $venta["total"]; ?></p>
    </div>

    <div class="tabla-contenedor detalle-tabla">
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio unitario</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = mysqli_fetch_assoc($resultado_detalle)) { ?>
                    <tr>
                        <td><?php echo $fila["producto"]; ?></td>
                        <td><?php echo $fila["cantidad"]; ?></td>
                        <td>S/ <?php echo $fila["precio_unitario"]; ?></td>
                        <td>S/ <?php echo $fila["subtotal"]; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <a class="boton-editar" href="listar.php">Volver</a>
    <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
    <?php } ?>
</main>

<?php include "../includes/footer.php"; ?>

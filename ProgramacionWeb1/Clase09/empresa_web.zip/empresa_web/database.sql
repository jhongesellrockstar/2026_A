-- Base de datos del miniproyecto Empresa Web
-- Sistema: Centro Comercial Electronica e Informatica Los Nisperos
-- Curso: Programacion Web I - ISEE405

CREATE DATABASE IF NOT EXISTS bd_empresa_web
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

USE bd_empresa_web;

-- Se eliminan primero las tablas hijas para respetar las claves foraneas.
DROP TABLE IF EXISTS detalle_ventas;
DROP TABLE IF EXISTS ventas;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS empleados;
DROP TABLE IF EXISTS clientes;

CREATE TABLE clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    dni VARCHAR(8) NOT NULL,
    telefono VARCHAR(15),
    correo VARCHAR(100),
    direccion VARCHAR(150),
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE empleados (
    id_empleado INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    cargo VARCHAR(50) NOT NULL,
    telefono VARCHAR(15),
    correo VARCHAR(100),
    fecha_contratacion DATE
);

CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(80) NOT NULL,
    descripcion VARCHAR(150)
);

CREATE TABLE productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    id_categoria INT NOT NULL,
    nombre_producto VARCHAR(100) NOT NULL,
    descripcion VARCHAR(150),
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
);

CREATE TABLE ventas (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_empleado INT NOT NULL,
    fecha_venta DATETIME DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
    FOREIGN KEY (id_empleado) REFERENCES empleados(id_empleado)
);

CREATE TABLE detalle_ventas (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_venta INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_venta) REFERENCES ventas(id_venta),
    FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
);

INSERT INTO clientes (nombres, dni, telefono, correo, direccion) VALUES
('Carlos Ramirez Torres', '45231890', '987654321', 'carlos.ramirez@email.com', 'Av. Saenz Pena 120 - Callao'),
('Maria Lopez Salazar', '43881234', '956123789', 'maria.lopez@email.com', 'Jr. Ayacucho 450 - Bellavista'),
('Jorge Huaman Rojas', '47665544', '923456781', 'jorge.huaman@email.com', 'Av. Colonial 780 - Callao'),
('Lucia Fernandez Paredes', '46221987', '914785236', 'lucia.fernandez@email.com', 'Av. Argentina 1500 - Callao'),
('Pedro Sanchez Molina', '40123876', '965478123', 'pedro.sanchez@email.com', 'Jr. Lima 321 - La Perla');

INSERT INTO empleados (nombres, cargo, telefono, correo, fecha_contratacion) VALUES
('Ana Torres Medina', 'Vendedora', '999111222', 'ana.torres@losnisperos.com', '2024-03-15'),
('Luis Castro Vega', 'Administrador', '988222333', 'luis.castro@losnisperos.com', '2023-08-01'),
('Rosa Quispe Leon', 'Cajera', '977333444', 'rosa.quispe@losnisperos.com', '2024-01-10');

INSERT INTO categorias (nombre_categoria, descripcion) VALUES
('Computadoras', 'Laptops y equipos de computo'),
('Accesorios', 'Perifericos y accesorios de uso diario'),
('Almacenamiento', 'Discos duros, SSD y memorias'),
('Redes', 'Equipos para conexion a internet y redes');

INSERT INTO productos (id_categoria, nombre_producto, descripcion, precio, stock) VALUES
(1, 'Laptop Lenovo IdeaPad', 'Laptop para oficina y estudio', 2450.00, 8),
(2, 'Mouse Logitech USB', 'Mouse optico con conexion USB', 45.00, 30),
(2, 'Teclado Genius', 'Teclado multimedia basico', 55.00, 25),
(1, 'Monitor Samsung 24 pulgadas', 'Monitor LED Full HD', 620.00, 10),
(3, 'Disco SSD Kingston 480GB', 'Unidad de estado solido SATA', 190.00, 12),
(3, 'Memoria RAM 8GB DDR4', 'Memoria para PC y laptop', 130.00, 14),
(1, 'Impresora Epson EcoTank', 'Impresora multifuncional a tinta', 890.00, 6),
(4, 'Router TP-Link AC1200', 'Router inalambrico doble banda', 160.00, 5);

INSERT INTO ventas (id_cliente, id_empleado, fecha_venta, total) VALUES
(1, 1, '2026-05-20 10:30:00', 2495.00),
(2, 3, '2026-05-21 15:10:00', 945.00),
(4, 1, '2026-05-22 11:45:00', 480.00);

INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES
(1, 1, 1, 2450.00, 2450.00),
(1, 2, 1, 45.00, 45.00),
(2, 7, 1, 890.00, 890.00),
(2, 3, 1, 55.00, 55.00),
(3, 5, 1, 190.00, 190.00),
(3, 6, 1, 130.00, 130.00),
(3, 8, 1, 160.00, 160.00);

<?php
$titulo_pagina = "Verificar instalacion";

// Este archivo verifica la instalacion sin usar conexion.php,
// para evitar un error fatal si la base de datos aun no existe.
$host = "localhost";
$usuario = "root";
$password = "";
$base_datos = "bd_empresa_web";
$tablas = array("clientes", "empleados", "categorias", "productos", "ventas", "detalle_ventas");
$estados = array();
$mensaje = "";

$conexion_servidor = mysqli_connect($host, $usuario, $password);

if (!$conexion_servidor) {
    $mensaje = "No se pudo conectar con MySQL. Verifica que MySQL este iniciado en XAMPP.";
} else {
    mysqli_set_charset($conexion_servidor, "utf8");

    $consulta_bd = mysqli_query($conexion_servidor, "SHOW DATABASES LIKE '$base_datos'");
    $existe_bd = $consulta_bd && mysqli_num_rows($consulta_bd) > 0;

    if (!$existe_bd) {
        $mensaje = "La base de datos bd_empresa_web no existe. Importa database.sql desde phpMyAdmin.";
    } else {
        mysqli_select_db($conexion_servidor, $base_datos);

        foreach ($tablas as $tabla) {
            $consulta_tabla = mysqli_query($conexion_servidor, "SHOW TABLES LIKE '$tabla'");
            $estados[$tabla] = $consulta_tabla && mysqli_num_rows($consulta_tabla) > 0 ? "OK" : "FALTA";
        }
    }
}

include "includes/header.php";
include "includes/menu.php";
?>

<main class="contenedor">
    <section class="encabezado-pagina">
        <h1>Verificar instalacion</h1>
        <p>Esta pagina revisa si la base de datos y sus tablas principales estan listas.</p>
    </section>

    <?php if ($mensaje != "") { ?>
        <div class="mensaje error"><?php echo $mensaje; ?></div>
    <?php } else { ?>
        <div class="mensaje ok">Conexion revisada. La base de datos fue encontrada.</div>
    <?php } ?>

    <div class="tabla-contenedor">
        <table>
            <thead>
                <tr>
                    <th>Elemento</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Base de datos bd_empresa_web</td>
                    <td><span class="<?php echo $mensaje == "" ? "estado-ok" : "estado-error"; ?>"><?php echo $mensaje == "" ? "OK" : "FALTA"; ?></span></td>
                </tr>
                <?php foreach ($tablas as $tabla) { ?>
                    <tr>
                        <td>Tabla <?php echo $tabla; ?></td>
                        <td>
                            <?php $estado = isset($estados[$tabla]) ? $estados[$tabla] : "FALTA"; ?>
                            <span class="<?php echo $estado == "OK" ? "estado-ok" : "estado-error"; ?>"><?php echo $estado; ?></span>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <div class="acciones margen-superior">
        <a class="boton-editar" href="index.php">Inicio</a>
        <a class="boton-secundario" href="dashboard.php">Dashboard</a>
        <a class="boton-editar" href="http://localhost/phpmyadmin/">phpMyAdmin</a>
    </div>
</main>

<?php include "includes/footer.php"; ?>

<?php
$titulo_pagina = "Dashboard";
include "conexion.php";

// Funcion simple para contar registros sin detener la pagina si una consulta falla.
function contar_registros($conexion, $tabla) {
    $consulta = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM $tabla");

    if ($consulta) {
        $fila = mysqli_fetch_assoc($consulta);
        return $fila["total"];
    }

    return "Error";
}

$total_clientes = contar_registros($conexion, "clientes");
$total_empleados = contar_registros($conexion, "empleados");
$total_productos = contar_registros($conexion, "productos");
$total_ventas = contar_registros($conexion, "ventas");

include "includes/header.php";
include "includes/menu.php";
?>

<main class="contenedor">
    <section class="encabezado-pagina">
        <h1>Panel principal</h1>
        <p>Indicadores y accesos principales del sistema empresarial.</p>
    </section>

    <?php if ($total_clientes === "Error" || $total_empleados === "Error" || $total_productos === "Error" || $total_ventas === "Error") { ?>
        <div class="mensaje error">No se pudieron cargar todos los indicadores. Revisa la base de datos o ejecuta verificar instalacion.</div>
    <?php } ?>

    <section class="indicadores">
        <div class="indicador">
            <span><?php echo $total_clientes; ?></span>
            <p>Clientes</p>
        </div>
        <div class="indicador">
            <span><?php echo $total_empleados; ?></span>
            <p>Empleados</p>
        </div>
        <div class="indicador">
            <span><?php echo $total_productos; ?></span>
            <p>Productos</p>
        </div>
        <div class="indicador">
            <span><?php echo $total_ventas; ?></span>
            <p>Ventas</p>
        </div>
    </section>

    <section class="tarjetas">
        <a class="tarjeta" href="clientes/listar.php">
            <span>Clientes</span>
            <p>Registrar, consultar, editar y eliminar clientes de la empresa.</p>
        </a>
        <a class="tarjeta" href="empleados/listar.php">
            <span>Empleados</span>
            <p>Administrar al personal encargado de la atencion y ventas.</p>
        </a>
        <a class="tarjeta" href="productos/listar.php">
            <span>Productos</span>
            <p>Controlar productos, categorias, precios y stock disponible.</p>
        </a>
        <a class="tarjeta" href="ventas/listar.php">
            <span>Ventas</span>
            <p>Registrar ventas simples y revisar los productos vendidos.</p>
        </a>
        <a class="tarjeta" href="verificar_instalacion.php">
            <span>Verificar instalacion</span>
            <p>Comprobar la base de datos y las tablas principales del sistema.</p>
        </a>
        <a class="tarjeta" href="documentacion_pasos/guia_sustentacion_docente.txt">
            <span>Documentacion</span>
            <p>Consultar la guia final para sustentar el proyecto en clase.</p>
        </a>
    </section>
</main>

<?php include "includes/footer.php"; ?>

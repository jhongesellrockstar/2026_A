<?php
// Datos de conexion usados por XAMPP.
$host = "localhost";
$usuario = "root";
$password = "";
$base_datos = "bd_empresa_web";

// mysqli_connect intenta conectar PHP con MySQL.
$conexion = mysqli_connect($host, $usuario, $password, $base_datos);

// Si la conexion falla, se muestra un mensaje claro para el estudiante.
if (!$conexion) {
    die("
        <div style='font-family: Arial; padding: 20px; background: #fff3f3; color: #8a1f1f; border: 1px solid #e0a0a0; margin: 30px; border-radius: 8px;'>
            <h2>Error de conexion a la base de datos</h2>
            <p>No se pudo conectar con MySQL. Verifica que Apache y MySQL esten iniciados en XAMPP.</p>
            <p>Tambien revisa que exista la base de datos <strong>bd_empresa_web</strong>.</p>
            <p><strong>Detalle:</strong> " . mysqli_connect_error() . "</p>
        </div>
    ");
}

// Se configura UTF-8 para mostrar tildes y caracteres especiales.
mysqli_set_charset($conexion, "utf8");
?>

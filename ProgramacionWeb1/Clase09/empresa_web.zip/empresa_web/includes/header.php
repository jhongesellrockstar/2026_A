<?php
// Header reutilizable. La variable $titulo_pagina se define en cada archivo.
if (!isset($titulo_pagina)) {
    $titulo_pagina = "Empresa Web";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo_pagina; ?> - Empresa Web</title>
    <link rel="stylesheet" href="/empresa_web/assets/css/estilos.css">
    <script src="/empresa_web/assets/js/validaciones.js" defer></script>
</head>
<body>

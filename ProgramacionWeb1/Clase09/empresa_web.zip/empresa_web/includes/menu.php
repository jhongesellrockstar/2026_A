<nav class="menu">
    <div class="menu-marca">Los N&iacute;speros</div>
    <ul>
        <li><a href="/empresa_web/index.php">Inicio</a></li>
        <li><a href="/empresa_web/dashboard.php">Dashboard</a></li>
        <li><a href="/empresa_web/clientes/listar.php">Clientes</a></li>
        <li><a href="/empresa_web/empleados/listar.php">Empleados</a></li>
        <li><a href="/empresa_web/productos/listar.php">Productos</a></li>
        <li><a href="/empresa_web/ventas/listar.php">Ventas</a></li>
        <li><a href="/empresa_web/verificar_instalacion.php">Verificar instalacion</a></li>
        <li><a href="/empresa_web/documentacion_pasos/guia_sustentacion_docente.txt">Documentacion</a></li>
    </ul>
</nav>

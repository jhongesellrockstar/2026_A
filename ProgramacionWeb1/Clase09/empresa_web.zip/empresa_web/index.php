<?php
$titulo_pagina = "Inicio";
include "includes/header.php";
?>

<main class="portada">
    <section class="portada-contenido">
        <p class="etiqueta">Sistema empresarial basico</p>
        <h1>Centro Comercial Electr&oacute;nica e Inform&aacute;tica Los N&iacute;speros</h1>
        <p>
            Módulo para el control de la administración de ventas , compras, clientes y otros;
            se considera que pueda explorar toda la plataforma.
        
        </p>
        <div class="portada-botones">
            <a class="boton-principal" href="dashboard.php">Entrar al dashboard</a>
            <a class="boton-claro" href="verificar_instalacion.php">Verificar instalacion</a>
            <a class="boton-claro" href="documentacion_pasos/guia_sustentacion_docente.txt">Ver documentacion</a>
        </div>
    </section>
</main>

<?php include "includes/footer.php"; ?>

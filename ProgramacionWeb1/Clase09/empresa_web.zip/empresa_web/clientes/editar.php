<?php
$titulo_pagina = "Editar cliente";
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombres = trim($_POST["nombres"]);
    $dni = trim($_POST["dni"]);
    $telefono = trim($_POST["telefono"]);
    $correo = trim($_POST["correo"]);
    $direccion = trim($_POST["direccion"]);

    if ($id <= 0 || empty($nombres) || empty($dni)) {
        $mensaje = "Los campos nombres y DNI son obligatorios.";
    } elseif (!ctype_digit($dni) || strlen($dni) != 8) {
        $mensaje = "El DNI debe tener exactamente 8 digitos.";
    } elseif ($telefono != "" && !preg_match("/^[0-9+\-\s]{6,15}$/", $telefono)) {
        $mensaje = "El telefono ingresado no tiene un formato valido.";
    } elseif ($correo != "" && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensaje = "El correo ingresado no tiene un formato valido.";
    } else {
        // mysqli_real_escape_string ayuda a evitar problemas con comillas en los textos.
        $nombres = mysqli_real_escape_string($conexion, $nombres);
        $dni = mysqli_real_escape_string($conexion, $dni);
        $telefono = mysqli_real_escape_string($conexion, $telefono);
        $correo = mysqli_real_escape_string($conexion, $correo);
        $direccion = mysqli_real_escape_string($conexion, $direccion);

        $sql = "UPDATE clientes SET nombres='$nombres', dni='$dni', telefono='$telefono',
                correo='$correo', direccion='$direccion' WHERE id_cliente=$id";

        if (mysqli_query($conexion, $sql)) {
            header("Location: listar.php?mensaje=Cliente actualizado correctamente");
            exit;
        } else {
            $mensaje = "No se pudo actualizar el cliente.";
        }
    }
}

$resultado = mysqli_query($conexion, "SELECT * FROM clientes WHERE id_cliente = $id");
$cliente = mysqli_fetch_assoc($resultado);

include "../includes/header.php";
include "../includes/menu.php";
?>

<main class="contenedor">
    <h1>Editar cliente</h1>
    <?php if ($mensaje != "") { ?><div class="mensaje error"><?php echo $mensaje; ?></div><?php } ?>

    <?php if (!$cliente) { ?>
        <div class="mensaje error">No se encontro el cliente solicitado.</div>
        <a class="boton-editar" href="listar.php">Volver</a>
    <?php } else { ?>
        <form class="formulario" id="formCliente" method="POST" onsubmit="return validarFormularioClientes()">
            <div class="campo">
                <label for="nombres">Nombres</label>
                <input type="text" id="nombres" name="nombres" value="<?php echo $cliente["nombres"]; ?>" placeholder="Ejemplo: Carlos Ramirez Torres" required>
            </div>
            <div class="campo">
                <label for="dni">DNI</label>
                <input type="text" id="dni" name="dni" value="<?php echo $cliente["dni"]; ?>" maxlength="8" minlength="8" pattern="[0-9]{8}" placeholder="8 digitos" required>
                <span class="ayuda">Debe contener exactamente 8 numeros.</span>
            </div>
            <div class="campo">
                <label for="telefono">Telefono</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo $cliente["telefono"]; ?>" maxlength="15" pattern="[0-9+\-\s]{6,15}" placeholder="Ejemplo: 987654321">
            </div>
            <div class="campo">
                <label for="correo">Correo</label>
                <input type="email" id="correo" name="correo" value="<?php echo $cliente["correo"]; ?>" placeholder="cliente@email.com">
            </div>
            <div class="campo">
                <label for="direccion">Direccion</label>
                <input type="text" id="direccion" name="direccion" value="<?php echo $cliente["direccion"]; ?>" maxlength="150" placeholder="Direccion del cliente">
            </div>
            <button class="boton-secundario" type="submit">Actualizar</button>
            <a class="boton-editar" href="listar.php">Cancelar</a>
            <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
        </form>
    <?php } ?>
</main>

<?php include "../includes/footer.php"; ?>

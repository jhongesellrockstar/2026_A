<?php
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

if ($id > 0) {
    $sql = "DELETE FROM clientes WHERE id_cliente = $id";

    if (mysqli_query($conexion, $sql)) {
        header("Location: listar.php?mensaje=Cliente eliminado correctamente");
        exit;
    }
}

header("Location: listar.php?error=No se pudo eliminar el cliente. Puede tener ventas registradas.");
exit;
?>

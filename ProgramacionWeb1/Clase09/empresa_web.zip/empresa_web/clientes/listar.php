<?php
$titulo_pagina = "Clientes";
include "../includes/header.php";
include "../includes/menu.php";
include "../conexion.php";

$consulta = "SELECT * FROM clientes ORDER BY id_cliente DESC";
$resultado = mysqli_query($conexion, $consulta);
?>

<main class="contenedor">
    <section class="encabezado-pagina acciones">
        <div>
            <h1>Clientes</h1>
            <p>Listado de clientes registrados en la empresa.</p>
        </div>
        <div>
            <a class="boton-secundario" href="crear.php">Nuevo cliente</a>
            <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
        </div>
    </section>

    <?php if (isset($_GET["mensaje"])) { ?><div class="mensaje ok"><?php echo $_GET["mensaje"]; ?></div><?php } ?>
    <?php if (isset($_GET["error"])) { ?><div class="mensaje error"><?php echo $_GET["error"]; ?></div><?php } ?>

    <div class="tabla-contenedor">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombres</th>
                    <th>DNI</th>
                    <th>Telefono</th>
                    <th>Correo</th>
                    <th>Direccion</th>
                    <th>Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                    <tr>
                        <td><?php echo $fila["id_cliente"]; ?></td>
                        <td><?php echo $fila["nombres"]; ?></td>
                        <td><?php echo $fila["dni"]; ?></td>
                        <td><?php echo $fila["telefono"]; ?></td>
                        <td><?php echo $fila["correo"]; ?></td>
                        <td><?php echo $fila["direccion"]; ?></td>
                        <td><?php echo $fila["fecha_registro"]; ?></td>
                        <td>
                            <a class="boton-editar" href="editar.php?id=<?php echo $fila["id_cliente"]; ?>">Editar</a>
                            <a class="boton-eliminar" href="eliminar.php?id=<?php echo $fila["id_cliente"]; ?>" onclick="return confirmarEliminacion('este cliente')">Eliminar</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</main>

<?php include "../includes/footer.php"; ?>

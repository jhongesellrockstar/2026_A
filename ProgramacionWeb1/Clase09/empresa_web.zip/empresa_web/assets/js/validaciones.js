// Funciones de validacion basica para formularios.
// Se usan alertas simples porque el proyecto esta en una etapa inicial.

function validarTextoObligatorio(valor, nombreCampo) {
    if (valor.trim() === "") {
        alert("El campo " + nombreCampo + " es obligatorio.");
        return false;
    }
    return true;
}

function validarDNI(valor) {
    const dni = valor.trim();
    const soloNumeros = /^[0-9]+$/;

    if (dni === "") {
        alert("El DNI es obligatorio.");
        return false;
    }

    if (dni.length !== 8 || !soloNumeros.test(dni)) {
        alert("El DNI debe tener exactamente 8 digitos.");
        return false;
    }

    return true;
}

function validarCorreo(valor) {
    const correo = valor.trim();
    const formatoCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (correo !== "" && !formatoCorreo.test(correo)) {
        alert("Ingresa un correo con formato valido.");
        return false;
    }

    return true;
}

function validarTelefono(valor) {
    const telefono = valor.trim();
    const formatoTelefono = /^[0-9+\-\s]{6,15}$/;

    if (telefono !== "" && !formatoTelefono.test(telefono)) {
        alert("Ingresa un telefono valido. Usa numeros, espacios o guiones.");
        return false;
    }

    return true;
}

function validarNumeroMayorCero(valor, nombreCampo) {
    const numero = Number(valor);

    if (valor === "" || isNaN(numero) || numero <= 0) {
        alert("El campo " + nombreCampo + " debe ser mayor que cero.");
        return false;
    }

    return true;
}

function validarNumeroMayorIgualCero(valor, nombreCampo) {
    const numero = Number(valor);

    if (valor === "" || isNaN(numero) || numero < 0) {
        alert("El campo " + nombreCampo + " debe ser igual o mayor que cero.");
        return false;
    }

    return true;
}

function validarFormularioClientes() {
    const nombres = document.getElementById("nombres").value;
    const dni = document.getElementById("dni").value;
    const telefono = document.getElementById("telefono").value;
    const correo = document.getElementById("correo").value;

    if (!validarTextoObligatorio(nombres, "nombres")) return false;
    if (!validarDNI(dni)) return false;
    if (!validarTelefono(telefono)) return false;
    if (!validarCorreo(correo)) return false;

    return true;
}

function validarFormularioEmpleados() {
    const nombres = document.getElementById("nombres").value;
    const cargo = document.getElementById("cargo").value;
    const telefono = document.getElementById("telefono").value;
    const correo = document.getElementById("correo").value;

    if (!validarTextoObligatorio(nombres, "nombres")) return false;
    if (!validarTextoObligatorio(cargo, "cargo")) return false;
    if (!validarTelefono(telefono)) return false;
    if (!validarCorreo(correo)) return false;

    return true;
}

function validarFormularioProductos() {
    const categoria = document.getElementById("id_categoria").value;
    const nombre = document.getElementById("nombre_producto").value;
    const precio = document.getElementById("precio").value;
    const stock = document.getElementById("stock").value;

    if (!validarTextoObligatorio(categoria, "categoria")) return false;
    if (!validarTextoObligatorio(nombre, "nombre del producto")) return false;
    if (!validarNumeroMayorCero(precio, "precio")) return false;
    if (!validarNumeroMayorIgualCero(stock, "stock")) return false;

    return true;
}

function validarFormularioVentas() {
    const cliente = document.getElementById("id_cliente").value;
    const empleado = document.getElementById("id_empleado").value;
    const producto = document.getElementById("id_producto").value;
    const cantidad = document.getElementById("cantidad").value;

    if (!validarTextoObligatorio(cliente, "cliente")) return false;
    if (!validarTextoObligatorio(empleado, "empleado")) return false;
    if (!validarTextoObligatorio(producto, "producto")) return false;
    if (!validarNumeroMayorCero(cantidad, "cantidad")) return false;

    return true;
}

function confirmarEliminacion(nombreRegistro) {
    return confirm("Deseas eliminar " + nombreRegistro + "? Esta accion no se puede deshacer.");
}

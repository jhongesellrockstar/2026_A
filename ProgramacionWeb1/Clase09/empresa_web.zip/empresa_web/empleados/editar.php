<?php
$titulo_pagina = "Editar empleado";
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombres = trim($_POST["nombres"]);
    $cargo = trim($_POST["cargo"]);
    $telefono = trim($_POST["telefono"]);
    $correo = trim($_POST["correo"]);
    $fecha_contratacion = trim($_POST["fecha_contratacion"]);

    if ($id <= 0 || empty($nombres) || empty($cargo)) {
        $mensaje = "Los campos nombres y cargo son obligatorios.";
    } elseif ($telefono != "" && !preg_match("/^[0-9+\-\s]{6,15}$/", $telefono)) {
        $mensaje = "El telefono ingresado no tiene un formato valido.";
    } elseif ($correo != "" && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensaje = "El correo ingresado no tiene un formato valido.";
    } elseif ($fecha_contratacion != "" && strtotime($fecha_contratacion) === false) {
        $mensaje = "La fecha de contratacion no es valida.";
    } else {
        // mysqli_real_escape_string ayuda a evitar problemas con comillas en los textos.
        $nombres = mysqli_real_escape_string($conexion, $nombres);
        $cargo = mysqli_real_escape_string($conexion, $cargo);
        $telefono = mysqli_real_escape_string($conexion, $telefono);
        $correo = mysqli_real_escape_string($conexion, $correo);
        $fecha_sql = "NULL";
        if ($fecha_contratacion != "") {
            $fecha_contratacion = mysqli_real_escape_string($conexion, $fecha_contratacion);
            $fecha_sql = "'$fecha_contratacion'";
        }

        $sql = "UPDATE empleados SET nombres='$nombres', cargo='$cargo',
                telefono='$telefono', correo='$correo', fecha_contratacion=$fecha_sql
                WHERE id_empleado=$id";

        if (mysqli_query($conexion, $sql)) {
            header("Location: listar.php?mensaje=Empleado actualizado correctamente");
            exit;
        } else {
            $mensaje = "No se pudo actualizar el empleado.";
        }
    }
}

$resultado = mysqli_query($conexion, "SELECT * FROM empleados WHERE id_empleado = $id");
$empleado = mysqli_fetch_assoc($resultado);

include "../includes/header.php";
include "../includes/menu.php";
?>

<main class="contenedor">
    <h1>Editar empleado</h1>
    <?php if ($mensaje != "") { ?><div class="mensaje error"><?php echo $mensaje; ?></div><?php } ?>

    <?php if (!$empleado) { ?>
        <div class="mensaje error">No se encontro el empleado solicitado.</div>
        <a class="boton-editar" href="listar.php">Volver</a>
    <?php } else { ?>
        <form class="formulario" id="formEmpleado" method="POST" onsubmit="return validarFormularioEmpleados()">
            <div class="campo">
                <label for="nombres">Nombres</label>
                <input type="text" id="nombres" name="nombres" value="<?php echo $empleado["nombres"]; ?>" placeholder="Ejemplo: Ana Torres Medina" required>
            </div>
            <div class="campo">
                <label for="cargo">Cargo</label>
                <input type="text" id="cargo" name="cargo" value="<?php echo $empleado["cargo"]; ?>" placeholder="Ejemplo: Vendedora" required>
            </div>
            <div class="campo">
                <label for="telefono">Telefono</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo $empleado["telefono"]; ?>" maxlength="15" pattern="[0-9+\-\s]{6,15}" placeholder="Ejemplo: 999111222">
            </div>
            <div class="campo">
                <label for="correo">Correo</label>
                <input type="email" id="correo" name="correo" value="<?php echo $empleado["correo"]; ?>" placeholder="empleado@losnisperos.com">
            </div>
            <div class="campo">
                <label for="fecha_contratacion">Fecha de contratacion</label>
                <input type="date" id="fecha_contratacion" name="fecha_contratacion" value="<?php echo $empleado["fecha_contratacion"]; ?>">
            </div>
            <button class="boton-secundario" type="submit">Actualizar</button>
            <a class="boton-editar" href="listar.php">Cancelar</a>
            <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
        </form>
    <?php } ?>
</main>

<?php include "../includes/footer.php"; ?>

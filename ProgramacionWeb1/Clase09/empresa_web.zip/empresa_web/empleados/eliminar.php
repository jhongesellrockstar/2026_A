<?php
include "../conexion.php";

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

if ($id > 0) {
    $sql = "DELETE FROM empleados WHERE id_empleado = $id";

    if (mysqli_query($conexion, $sql)) {
        header("Location: listar.php?mensaje=Empleado eliminado correctamente");
        exit;
    }
}

header("Location: listar.php?error=No se pudo eliminar el empleado. Puede tener ventas registradas.");
exit;
?>

<?php
$titulo_pagina = "Nuevo empleado";
include "../conexion.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombres = trim($_POST["nombres"]);
    $cargo = trim($_POST["cargo"]);
    $telefono = trim($_POST["telefono"]);
    $correo = trim($_POST["correo"]);
    $fecha_contratacion = trim($_POST["fecha_contratacion"]);

    if (empty($nombres) || empty($cargo)) {
        $mensaje = "Los campos nombres y cargo son obligatorios.";
    } elseif ($telefono != "" && !preg_match("/^[0-9+\-\s]{6,15}$/", $telefono)) {
        $mensaje = "El telefono ingresado no tiene un formato valido.";
    } elseif ($correo != "" && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensaje = "El correo ingresado no tiene un formato valido.";
    } elseif ($fecha_contratacion != "" && strtotime($fecha_contratacion) === false) {
        $mensaje = "La fecha de contratacion no es valida.";
    } else {
        // mysqli_real_escape_string ayuda a evitar problemas con comillas en los textos.
        $nombres = mysqli_real_escape_string($conexion, $nombres);
        $cargo = mysqli_real_escape_string($conexion, $cargo);
        $telefono = mysqli_real_escape_string($conexion, $telefono);
        $correo = mysqli_real_escape_string($conexion, $correo);
        $fecha_sql = "NULL";
        if ($fecha_contratacion != "") {
            $fecha_contratacion = mysqli_real_escape_string($conexion, $fecha_contratacion);
            $fecha_sql = "'$fecha_contratacion'";
        }

        $sql = "INSERT INTO empleados (nombres, cargo, telefono, correo, fecha_contratacion)
                VALUES ('$nombres', '$cargo', '$telefono', '$correo', $fecha_sql)";

        if (mysqli_query($conexion, $sql)) {
            header("Location: listar.php?mensaje=Empleado registrado correctamente");
            exit;
        } else {
            $mensaje = "No se pudo registrar el empleado.";
        }
    }
}

include "../includes/header.php";
include "../includes/menu.php";
?>

<main class="contenedor">
    <h1>Nuevo empleado</h1>
    <?php if ($mensaje != "") { ?><div class="mensaje error"><?php echo $mensaje; ?></div><?php } ?>

    <form class="formulario" id="formEmpleado" method="POST" onsubmit="return validarFormularioEmpleados()">
        <div class="campo">
            <label for="nombres">Nombres</label>
            <input type="text" id="nombres" name="nombres" placeholder="Ejemplo: Ana Torres Medina" required>
        </div>
        <div class="campo">
            <label for="cargo">Cargo</label>
            <input type="text" id="cargo" name="cargo" placeholder="Ejemplo: Vendedora" required>
        </div>
        <div class="campo">
            <label for="telefono">Telefono</label>
            <input type="text" id="telefono" name="telefono" maxlength="15" pattern="[0-9+\-\s]{6,15}" placeholder="Ejemplo: 999111222">
        </div>
        <div class="campo">
            <label for="correo">Correo</label>
            <input type="email" id="correo" name="correo" placeholder="empleado@losnisperos.com">
        </div>
        <div class="campo">
            <label for="fecha_contratacion">Fecha de contratacion</label>
            <input type="date" id="fecha_contratacion" name="fecha_contratacion">
        </div>
        <button class="boton-secundario" type="submit">Guardar</button>
        <a class="boton-editar" href="listar.php">Cancelar</a>
        <a class="boton-editar" href="../dashboard.php">Volver al dashboard</a>
    </form>
</main>

<?php include "../includes/footer.php"; ?>
